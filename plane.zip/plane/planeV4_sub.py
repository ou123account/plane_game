import pygame
import random


class Hero:
    def __init__(self, img, pos):
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.speed = 10

    def up(self):
        self.rect.y -= self.speed
        if self.rect.top <= 0:
            self.rect.y = 0

    def down(self):
        self.rect.y += self.speed
        if self.rect.bottom >= 600:
            self.rect.bottom = 600

    def left(self):
        self.rect.x -= self.speed
        if self.rect.left <= 0:
            self.rect.x = 0

    def right(self):
        self.rect.x += self.speed
        if self.rect.right >= 800:
            self.rect.right = 800

    def shoot(self, img: pygame.image, group: pygame.sprite.Group):
        bullet = Bullet(img, self.rect.midtop)
        bullet2 = Bullet(img, (self.rect.centerx+30, self.rect.centery))
        bullet3 = Bullet(img, (self.rect.centerx-30, self.rect.centery))
        group.add(bullet)
        # group.add(bullet2)
        # group.add(bullet3)

    def enemy_show(self, img: pygame.image, group: pygame.sprite.Group):
        enemy = Enemy(img, (random.randint(30, 760), 0))
        if random.random() <= 0.2:
            group.add(enemy)


class Bullet(pygame.sprite.Sprite):
    def __init__(self, img, pos):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect(midbottom=pos)
        self.speed = 24

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()


class Enemy(pygame.sprite.Sprite):
    def __init__(self, img, pos):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect(midtop=pos)
        self.speed = 5

    def update(self):
        self.rect.y += self.speed
        if self.rect.bottom < 0:
            self.kill()
