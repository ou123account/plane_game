import pygame
from pygame.locals import *
import sys
from planeV3_sub import Hero
"""
pygame 子模块
|--display 窗口 
|--font    字体
|--image   图片
|--mixer   声音
|--event   事件
|--draw    画图
|--sprite  精灵（角色）
"""
"""
version info

V20220529_0.8  start up image and draw_font
V20220604_1.6  enter the game and show the plane and use up down left right w a s d to control the plane
V20220610_2.4h3  added bullet
"""
# game var
bg_image = "resources/image/background.png"
bg_image1 = "resources/image/background2.png"
bg_image2 = "resources/image/background3.png"
shoot_img = "resources/image/shoot.png"

# init
pygame.init()


class MainWin:
    def __init__(self):
        self.screen = pygame.display.set_mode([700, 600])
        pygame.display.set_caption("planeV3")
        self.bg = pygame.image.load(bg_image)
        self.bg1 = pygame.image.load(bg_image1)
        self.bg = pygame.transform.scale(self.bg, (700, 600))
        self.bg2 = pygame.image.load(bg_image2)
        self.shoot = pygame.image.load(shoot_img)
        self.hero1 = self.shoot.subsurface(0, 99, 102, 126)
        self.hero2 = self.shoot.subsurface(165, 360, 102, 126)
        self.bullet1 = self.shoot.subsurface(1004, 987, 9, 21)
        self.bullet2 = self.shoot.subsurface(69, 78, 9, 21)
        self.myplane = Hero(self.hero1, (600 // 2, 800 / 2))
        self.bullet_group = pygame.sprite.Group()
        self.game_situation = 0
        """
        game_situation
        0:用户准备状态
        1:游戏进行中
        2:游戏失败
        """

    def draw_text(self, text, color, pos, size=40):
        my_font = pygame.font.Font("resources/font/myfont.ttf", size)
        my_text = my_font.render(text, True, color)
        my_rect = my_text.get_rect()
        my_rect.center = pos
        self.screen.blit(my_text, my_rect)

    def key_pressing(self):
        key_press = pygame.key.get_pressed()
        if key_press[pygame.K_UP]:
            self.myplane.up()
        if key_press[pygame.K_DOWN]:
            self.myplane.down()
        if key_press[pygame.K_LEFT]:
            self.myplane.left()
        if key_press[pygame.K_RIGHT]:
            self.myplane.right()
        if key_press[pygame.K_j]:
            self.myplane.shoot(self.bullet1, self.bullet_group)

    def check_event(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_SPACE:
                    self.game_situation = 1

    def show(self):
        while True:
            if self.game_situation == 0:
                self.screen.blit(self.bg, (0, 0))
                self.draw_text("飞机大战", (200, 30, 40), (700 // 2, 600 // 4), 80)
                self.draw_text("V20220611_2.4h3", (20, 180, 40), (700 // 2, 600 // 4 + 100), 30)
                self.draw_text("press space to start", (20, 180, 40), (700 // 2, 600 // 4 + 120), 25)

                self.check_event()
            if self.game_situation == 1:
                self.screen = pygame.display.set_mode([800, 600])
                hero_rect = self.hero1.get_rect(center=(800//2, 600//2+200))
                self.screen.blit(self.bg1, (0, 0))
                self.screen.blit(self.myplane.image, self.myplane.rect)
                self.bullet_group.draw(self.screen)
                self.bullet_group.update()
                self.check_event()
                self.key_pressing()
            pygame.display.update()


if __name__ == '__main__':
    win = MainWin()
    win.show()
