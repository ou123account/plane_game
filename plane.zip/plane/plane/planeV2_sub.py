class Hero:
    def __init__(self, img, pos):
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.speed = 10

    def up(self):
        self.rect.y -= self.speed
        if self.rect.top <= 0:
            self.rect.y = 0

    def down(self):
        self.rect.y += self.speed
        if self.rect.bottom >= 600:
            self.rect.bottom = 600

    def left(self):
        self.rect.x -= self.speed
        if self.rect.left <= 0:
            self.rect.x = 0

    def right(self):
        self.rect.x += self.speed
        if self.rect.right >= 800:
            self.rect.right = 800



