import pygame
from pygame.locals import *
import sys
"""
pygame 子模块
|--display 窗口 
|--font    字体
|--image   图片
|--mixer   声音
|--event   事件
|--draw    画图
|--sprite  精灵（角色）
"""

WIDTH = 400
HEIGHT = 800
bg_image = "resources/image/background.png"

pygame.init()


class MainWin:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.bg = pygame.image.load(bg_image)
        pygame.display.set_caption("planeV1")

    def draw_text(self, text, color, pos, size=40):
        my_font = pygame.font.Font("resources/font/myfont.ttf", size)
        my_text = my_font.render(text, True, color)
        my_rect = my_text.get_rect()
        my_rect.center = pos
        self.screen.blit(my_text, my_rect)

    def check_event(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

    def show(self):
        while True:
            self.screen.blit(self.bg, (0, 0))
            self.check_event()
            self.draw_text("飞机大战", (200, 30, 40), (WIDTH // 2, HEIGHT // 4), 80)
            self.draw_text("V20220529_0.8", (20, 180, 40), (WIDTH // 2, HEIGHT // 4 + 100), 30)
            pygame.display.update()


if __name__ == '__main__':
    win = MainWin()
    win.show()
