import pygame
from pygame.locals import *
import sys
from planeV2_sub import Hero
"""
pygame 子模块
|--display 窗口 
|--font    字体
|--image   图片
|--mixer   声音
|--event   事件
|--draw    画图
|--sprite  精灵（角色）
"""
"""
version info

V20220529_0.8  start up image and draw_font
V20220604_1.6  enter the game and show the plane and use up down left right w a s d to control the plane
"""
# game var
bg_image = "resources/image/background.png"
bg_image1 = "resources/image/background2.png"
bg_image2 = "resources/image/background3.png"
shoot_img = "resources/image/shoot.png"

# init
pygame.init()


class MainWin:
    def __init__(self):
        self.screen = pygame.display.set_mode([400, 800])
        self.bg = pygame.image.load(bg_image)
        self.bg1 = pygame.image.load(bg_image1)
        self.bg2 = pygame.image.load(bg_image2)
        self.shoot = pygame.image.load(shoot_img)
        self.hero1 = self.shoot.subsurface(0, 99, 102, 126)
        self.hero2 = self.shoot.subsurface(165, 360, 102, 126)
        self.myplane = Hero(self.hero1, (600 // 2, 800 / 2))
        self.game_situation = 0
        """
        game_situation
        0:用户准备状态
        1:游戏进行中
        2:游戏失败
        """
        pygame.display.set_caption("planeV2")

    def draw_text(self, text, color, pos, size=40):
        my_font = pygame.font.Font("resources/font/myfont.ttf", size)
        my_text = my_font.render(text, True, color)
        my_rect = my_text.get_rect()
        my_rect.center = pos
        self.screen.blit(my_text, my_rect)

    def check_event(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                key_press = pygame.key.get_pressed()
                if event.key == pygame.K_SPACE:
                    self.game_situation = 1
                if key_press[pygame.K_UP]:
                    self.myplane.up()
                if key_press[pygame.K_DOWN]:
                    self.myplane.down()
                if key_press[pygame.K_LEFT]:
                    self.myplane.left()
                if key_press[pygame.K_RIGHT]:
                    self.myplane.right()

    def show(self):
        while True:
            if self.game_situation == 0:
                self.screen.blit(self.bg, (0, 0))
                self.draw_text("飞机大战", (200, 30, 40), (400 // 2, 800 // 4), 80)
                self.draw_text("V20220604_1.6", (20, 180, 40), (400 // 2, 800 // 4 + 100), 30)
                self.draw_text("press space to start", (20, 180, 40), (400 // 2, 800 // 4 + 120), 25)
                self.check_event()
            if self.game_situation == 1:
                self.screen = pygame.display.set_mode([800, 600])
                hero_rect = self.hero1.get_rect(center=(800//2, 600//2+200))
                self.screen.blit(self.bg1, (0, 0))
                self.screen.blit(self.myplane.image, self.myplane.rect)
                self.check_event()
            pygame.display.update()


if __name__ == '__main__':
    win = MainWin()
    win.show()
