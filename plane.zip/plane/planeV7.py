import pygame
from pygame.locals import *
import sys
import random
"""
pygame 子模块
|--display 窗口 
|--font    字体
|--image   图片
|--mixer   声音
|--event   事件
|--draw    画图 
|--sprite  精灵（角色）
|--joystick  硬件
"""
"""
version info
V20220529_0.8  start up image and draw_font
V20220604_1.6  enter the game and show the plane and use up down left right to control the plane1
V20220610_2.4h3  added bullet
V20220611_3.2h4  added enemy first commit
V20220618_4.0h5  added background sound, healthbar
V20220623_4.8h6  added score, game_over
V20220625_5.6h7 added plane2  how to control:w a s d
"""
# game var
bg_image = "resources/resources/image/background.png"
bg_image1 = "resources/resources/image/background2.png"
bg_image2 = "resources/resources/image/background3.png"
game_over_png = "resources/resources/image/gameover.png"
shoot_img = "resources/resources/image/shoot.png"
bg_sound = "resources/resources/sound/game_music.mp3"
bullet_sound = "resources/resources/sound/bullet.mp3"

w = 1300
h = 750

# init
pygame.init()


class MainWin:
    def __init__(self):
        self.screen = pygame.display.set_mode([700, 600])
        pygame.display.set_caption("planeV5")
        self.bg = pygame.image.load(bg_image)
        self.bg1 = pygame.image.load(bg_image1)
        self.bg = pygame.transform.scale(self.bg, (700, 600))
        self.bg2 = pygame.image.load(bg_image2)
        self.bg2 = pygame.transform.scale(self.bg2, (w, h))
        self.shoot = pygame.image.load(shoot_img)
        self.game_over = pygame.image.load(game_over_png)
        self.heros1 = [self.shoot.subsurface(0, 99, 102, 126), self.shoot.subsurface(165, 360, 102, 126)]
        self.heros2 = [pygame.image.load("resources/resources/image/hero2_1.png"), pygame.image.load("resources/resources/image/hero2_2.png")]
        self.bullet1 = self.shoot.subsurface(1004, 987, 9, 21)
        self.bullet2 = self.shoot.subsurface(69, 78, 9, 21)
        self.enemy1 = self.shoot.subsurface(534, 612, 57, 43)
        self.myplane = Hero(self.heros1[0], (w // 3, h // 2))
        self.myplane_2 = Hero(self.heros2[0], (w * 2 // 3, h // 2))
        self.health_value = 1000
        self.score = 0
        self.bullet_group = pygame.sprite.Group()
        self.enemy_group = pygame.sprite.Group()
        self.game_situation = 0
        """
        game_situation
        0:用户准备状态
        1:游戏进行中
        2:游戏失败
        3.游戏胜利
        """

    def draw_text(self, text, color, pos, size=40):
        my_font = pygame.font.Font("resources/resources/font/myfont.ttf", size)
        my_text = my_font.render(text, True, color)
        my_rect = my_text.get_rect()
        my_rect.center = pos
        self.screen.blit(my_text, my_rect)

    def draw_rect(self, color, pos, life):
        pygame.draw.rect(self.screen, color, (pos, (life, 30)))

    def key_pressing(self):
        key_press = pygame.key.get_pressed()
        if key_press[pygame.K_UP]:
            self.myplane.up()
        if key_press[pygame.K_DOWN]:
            self.myplane.down()
        if key_press[pygame.K_LEFT]:
            self.myplane.left()
        if key_press[pygame.K_RIGHT]:
            self.myplane.right()
        if key_press[pygame.K_j]:
            self.myplane.shoot(self.bullet1, self.bullet_group)
            self.myplane.bullets += 1
        if key_press[pygame.K_w]:
            self.myplane_2.up()
        if key_press[pygame.K_s]:
            self.myplane_2.down()
        if key_press[pygame.K_a]:
            self.myplane_2.left()
        if key_press[pygame.K_d]:
            self.myplane_2.right()
        if key_press[pygame.K_h]:
            self.myplane_2.shoot(self.bullet2, self.bullet_group)
            self.myplane_2.bullets += 1

    def check_event(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_SPACE:
                    self.game_situation = 1

    def music(self, sound):
        pygame.mixer.init()
        pygame.mixer.music.load(sound)
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)

    def gameover(self):
        self.screen = pygame.display.set_mode((400, 800))
        self.screen.blit(self.game_over, (0, 0))
        self.music("resources/sound/game_over.mp3")



    def show(self):
        self.music(bg_sound)
        heroshi = 0
        while True:
            heroshi += 1
            if self.game_situation == 0:
                self.screen.blit(self.bg, (0, 0))
                self.draw_text("飞机大战", (200, 30, 40), (700 // 2, 600 // 4), 80)
                self.draw_text("V20220625_5.6h7", (20, 180, 40), (700 // 2, 600 // 4 + 100), 30)
                self.draw_text("press space to start", (20, 180, 40), (700 // 2, 600 // 4 + 120), 25)
                self.check_event()
            elif self.game_situation == 1:
                self.myplane.image = self.heros1[heroshi % 2]
                self.myplane_2.image = self.heros2[heroshi % 2]
                self.screen = pygame.display.set_mode([w, h])
                self.screen.blit(self.bg2, (0, 0))
                self.draw_text(f"score:{self.score}", (236, 88, 94), (40, 20), 20)
                self.screen.blit(self.myplane.image, self.myplane.rect)
                self.screen.blit(self.myplane_2.image, self.myplane_2.rect)
                self.bullet_group.draw(self.screen)
                self.enemy_group.draw(self.screen)
                self.bullet_group.update()
                self.enemy_group.update()
                self.check_event()
                self.myplane.enemy_show(self.enemy1, self.enemy_group)
                self.key_pressing()
                self.draw_rect((255, 0, 0), (290, 10), 1000)
                self.draw_rect((0, 255, 0), (290, 10), self.health_value)
                bullethit = pygame.sprite.groupcollide(self.bullet_group, self.enemy_group, True, True)
                if bullethit:
                    self.score += len(bullethit)
                enemyhit = pygame.sprite.spritecollide(self.myplane, self.enemy_group, True)
                enemyh1t = pygame.sprite.spritecollide(self.myplane_2, self.enemy_group, True)
                if enemyhit or enemyh1t:
                    self.health_value -= len(enemyhit)*2
                    if self.health_value <= 0:
                        self.game_situation = 2

            elif self.game_situation == 2:
                self.gameover()
                self.check_event()

            pygame.display.update()


class Hero:
    def __init__(self, img, pos):
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.speed = 10
        self.bullets = 0

    def up(self):
        self.rect.y -= self.speed
        if self.rect.top <= 0:
            self.rect.y = 0

    def down(self):
        self.rect.y += self.speed
        if self.rect.bottom >= h:
            self.rect.bottom = h

    def left(self):
        self.rect.x -= self.speed
        if self.rect.left <= 0:
            self.rect.x = 0

    def right(self):
        self.rect.x += self.speed
        if self.rect.right >= w:
            self.rect.right = w

    def shoot(self, img: pygame.image, group: pygame.sprite.Group):
        bullet = Bullet(img, self.rect.midtop)
        bullet2 = Bullet(img, (self.rect.centerx+30, self.rect.centery))
        bullet3 = Bullet(img, (self.rect.centerx-30, self.rect.centery))
        group.add(bullet)
        pygame.mixer.Sound(bullet_sound).play()

        # group.add(bullet2)
        # group.add(bullet3)

    def enemy_show(self, img: pygame.image, group: pygame.sprite.Group):
        enemy = Enemy(img, (random.randint(30, w-30), 0))
        if random.random() <= 0.2:
            group.add(enemy)


class Bullet(pygame.sprite.Sprite):
    def __init__(self, img, pos):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect(midbottom=pos)
        self.speed = 24

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()


class Enemy(pygame.sprite.Sprite):
    def __init__(self, img, pos):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect(midtop=pos)
        self.speed = 5

    def update(self):
        self.rect.y += self.speed
        if self.rect.bottom < 0:
            self.kill()


if __name__ == '__main__':
    win = MainWin()
    win.show()
